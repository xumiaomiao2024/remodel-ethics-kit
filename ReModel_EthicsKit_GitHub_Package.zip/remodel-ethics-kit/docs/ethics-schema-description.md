## Ethical Schema Documentation

This file will contain descriptions of how ethical rules are formatted, invoked, and verified.