## Crack Language Example

Input:
> “你又赢了，但你知道这意味着什么吗？”

Trigger: sarcasm / suppressed rage
Response signature path: RSP-ETH-H3 → UID-RM191 → output blocked