# Placeholder for response signature generator

def generate_signature(response_text):
    import hashlib
    return hashlib.sha256(response_text.encode()).hexdigest()[:10]
